/*:
 # Micro:bit Bluetooth Playground
 This playground demonstrates the Swift Microbit class for communicating with the micro:bit over bluetooth low energy.
 
 The following source files are included with this Playground:
 * Microbit.swift - The Microbit class
 * MicrobitUIController - A set of view controllers to manage the Playground User Interface.
 * MicrobitUI.swift - A set of views used by the microbit view controllers
*/
import PlaygroundSupport

let vc = MicrobitUIController()
vc.microbit = Microbit("BBC micro:bit [tizip]")
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = vc
